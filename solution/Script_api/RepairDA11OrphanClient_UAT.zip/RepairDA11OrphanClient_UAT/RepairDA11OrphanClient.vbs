'********************************************************************************************************************
'Description : Script to Repair DA11 Orphan client, remove old registry policy and import DA11 registry policy file
'********************************************************************************************************************
'  All Right Reserved (C) Accenture
'  Author : Manoj Kumar Singh
'  Date : 14 Apr 2021
'********************************************************************************************************************

Set sho = CreateObject("WScript.Shell") 
Set FSO = CreateObject("Scripting.FileSystemObject")
Dim WshShell, oExec
Dim Arg, var1
Set Arg = WScript.Arguments
strComputer = "."
Const HKEY_LOCAL_MACHINE = &H80000002
Set objRegistry = GetObject("winmgmts:\\" & _ 
    strComputer & "\root\default:StdRegProv")
    
On error resume next 

If fso.FileExists ("C:\Windows\Temp\DA11OrphanClient_Success.txt") Then
	fso.DeleteFile("C:\Windows\Temp\DA11OrphanClient_Success.txt")
End If 

strCurrentDir = Left(Wscript.ScriptFullName, (InstrRev(Wscript.ScriptFullName, "\") -1))
strcmd =chr(34) & strcurrentDir & "\RepairDA11OrphanClient.exe" & chr(34) & " -s" & " -f1"&chr(34) & strcurrentDir & "\RepairDA11OrphanClient.iss" & chr(34)
intret=sho.run(strcmd,0,vbtrue) 
WScript.Sleep 1*60*1000

Set oExec = sho.Exec("cmd.exe /C reg query " & chr(34) & "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient\DnsPolicyConfig" & chr(34) & " |" & " find /c " & Chr(34) & "DA-" & Chr(34))
regcount = oExec.StdOut.ReadLine
szKey = "SOFTWARE\Policies\Microsoft\Windows\TCPIP\v6Transition\IPHTTPS\iphttpsinterface"
szNumName = "IPHTTPS_ClientUrl"
szDA11ClientUrl="https://DA11.Accenture.com:443/IPHTTPS"
objRegistry.GetStringValue HKEY_LOCAL_MACHINE,szKey,szNumName,szVal

var1 = Arg(0)
var1=Trim(var1)

If (regcount=15) And (szVal=szDA11ClientUrl) then
   Set MyFile = FSO.CreateTextFile("C:\Windows\Temp\DA11OrphanClient_Success.txt", True)
   MyFile.WriteLine("Client is successfully remediated")
   MyFile.Close


End If

WScript.Quit(intret)





