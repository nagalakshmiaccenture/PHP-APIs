﻿##Create EVTA Registry Values##
Function Create-EVTASetupKey
 {
 #write-host "Checking spotkey"
 $spotpath = test-path TempHive:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
    if ($spotpath -eq 'True')
    {
    if((Get-ItemProperty TempHive:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce -Name EVTASETUP -ea 0).ServiceURL) {
       
        #Write-Host "value exists"
       
    
        }

    ELSE {
    #write-host "value does not exists, creating value"
        Set-ItemProperty -Path TempHive:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce -Name EVTASETUP -Value '"C:\Programdata\Accenture\EVTA\AccentureEVTAsetup.vbs"' | Out-Null
      
        } 

    }
    else
    {
    new-item TempHive:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce -ErrorAction SilentlyContinue | Out-NUll
   
    create-EVTAsetupkey
    }

 }

##Registry Write Functions##
Function Import-RegistryHive
{
    [CmdletBinding()]
    Param(
        [String][Parameter(Mandatory=$true)]$File,
        # check the registry key name is not an invalid format
        [String][Parameter(Mandatory=$true)][ValidatePattern('^(HKLM\\|HKCU\\)[a-zA-Z0-9- _\\]+$')]$Key,
        # check the PSDrive name does not include invalid characters
        [String][Parameter(Mandatory=$true)][ValidatePattern('^[^;~/\\\.\:]+$')]$Name
    )

    # check whether the drive name is available
    $TestDrive = Get-PSDrive -Name $Name -EA SilentlyContinue
    if ($TestDrive -ne $null)
    {
        throw [Management.Automation.SessionStateException] "A drive with the name '$Name' already exists."
    }

    $Process = Start-Process -FilePath "$env:WINDIR\system32\reg.exe" -ArgumentList "load $Key $File" -WindowStyle Hidden -PassThru -Wait

    if ($Process.ExitCode)
    {
        throw [Management.Automation.PSInvalidOperationException] "The registry hive '$File' failed to load. Verify the source path or target registry key."
    }

    try
    {
        # validate patten on $Name in the Params and the drive name check at the start make it very unlikely New-PSDrive will fail
        New-PSDrive -Name $Name -PSProvider Registry -Root $Key -Scope Global -EA Stop | Out-Null
    }
    catch
    {
        throw [Management.Automation.PSInvalidOperationException] "A critical error creating drive '$Name' has caused the registy key '$Key' to be left loaded, this must be unloaded manually."
    }
}

Function Remove-RegistryHive
{
    [CmdletBinding()]
    Param(
        [String][Parameter(Mandatory=$true)][ValidatePattern('^[^;~/\\\.\:]+$')]$Name
    )

    # set -ErrorAction Stop as we never want to proceed if the drive doesnt exist
    $Drive = Get-PSDrive -Name $Name -EA Stop
    # $Drive.Root is the path to the registry key, save this before the drive is removed
    $Key = $Drive.Root

    # remove the drive, the only reason this should fail is if the resource is busy
    Remove-PSDrive $Name -EA Stop

    $Process = Start-Process -FilePath "$env:WINDIR\system32\reg.exe" -ArgumentList "unload $Key" -WindowStyle Hidden -PassThru -Wait
    if ($Process.ExitCode)
    {
        # if "reg unload" fails due to the resource being busy, the drive gets added back to keep the original state
        New-PSDrive -Name $Name -PSProvider Registry -Root $Key -Scope Global -EA Stop | Out-Null
        throw [Management.Automation.PSInvalidOperationException] "The registry key '$Key' could not be unloaded, the key may still be in use."
    }
}

##Main Routine##
if(!(Test-Path -Path 'C:\Programdata\Accenture'))
{
    New-Item 'C:\Programdata\Accenture' -Type Directory -Force
}
New-Item -Path 'C:\Programdata\Accenture' -Name "EVTA" -ItemType Directory -Force
Copy-Item -Path .\* -Destination 'C:\Programdata\Accenture\EVTA' -Force -Recurse
#Copy-Item -Path .\AccentureEVTAsetup.vbs -Destination 'C:\Programdata\Accenture\EVTA' -Force

Import-RegistryHive -File 'C:\Users\Default\NTUSER.DAT' -Key 'HKLM\TEMP_HIVE' -Name TempHive -Verbose

#Copy-Item -Path Registry::HKLM\Software\Masksettings -Destination Registry::HKLM\TEMP_HIVE\Software -Recurse

#cd $PSScriptRoot
#regedit /s .\Masksettings.reg

Create-EVTASetupKey

# attempt Remove-RegistryHive a maximum of 3 times
$attempt = 0
while($true)
{
    try
    {
        # when Remove-RegistryHive is successful break will stop the loop
        $attempt++
        Remove-RegistryHive -Name TempHive
        #Write-Host 'NTUSER.DAT updated successfully!'
        break
    }
    catch
    {
        if ($attempt -eq 3)
        {
            # rethrow the exception, we gave up
            throw
        }

        #Write-Host 'Remove-RegistryHive failed, trying again...'

        # wait for 100ms and trigger the garbage collector
        Start-Sleep -Milliseconds 100
        [gc]::Collect()
    }
}

#$output = (Start-Process -FilePath msiexec.exe -ArgumentList "/i", "C:\Programdata\Accenture\EVTA\AccentureExternalEmailValidationAddinSetup-new.msi", "/qn", "/L*v %temp%\EVTA_Install.log" -PassThru -Wait).ExitCode

#exit($output)