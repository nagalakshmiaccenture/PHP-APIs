'*************************************************************************************************************************************************
'Description: Script to uninstall Email Validation Tool for Accenture v1.0
'*************************************************************************************************************************************************
'  All Right Reserved (C) Accenture
'  Author : Sourabh Krishna, Venkatesh.K, Arun Viswanath, Sethi, Narayan
'  Date : 15 March 2019
'*************************************************************************************************************************************************
' Check if the script is running with elevated previlages. If not restart with elevated previlages.
	'-------- Execute Code present here with admin rights ---------------
	' 1. Fetch the outlook version from the registry - Computer\HKEY_CLASSES_ROOT\Outlook.Application\CurVer
	' 2. Execute the appropriate Reg file present in the reg folder

		On error resume next 
		strComputer = "."
		Dim oWsh,fso,oReg , strUninstall, strCheck , strValueafterinstall , toolVersion
		toolVersion = "1.0.2.0"
		strUninstall = "Uninstall"
		strCheck = "Check"
		Set oWsh = CreateObject("WScript.Shell")
		Set oReg=GetObject("winmgmts:{impersonationLevel=impersonate}!\\" & _
		strComputer & "\root\default:StdRegProv") 
		Set fso = CreateObject("Scripting.FileSystemObject")
		tmpFolder = oWsh.ExpandEnvironmentStrings("%Windir%")
		tmpFolder1 = tmpFolder & "\Temp"
		strCurrentDir = Left(Wscript.ScriptFullName, (InstrRev(Wscript.ScriptFullName, "\") -1))
		Const HKEY_LOCAL_MACHINE = &H80000002
		
		'*************************************************************************************************************************************************
		
		WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Script Started**************"
		Err.Clear
		On error resume next 
		Err.Clear
		TempCount = InStr(strCurrentDir,"\appData\local\Accenture\") + InStr(strCurrentDir,"\AppData\Local\Accenture\")
		ZipCount = InStr(strCurrentDir, ".zip")
		
		If (ZipCount <> 0) OR (TempCount <> 0) Then
			'MsgBox "Requesting you to un-zip the contents of the zip file and then install the tool."
		else
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Check if tool is already installed**************"
			hDefKey = HKEY_LOCAL_MACHINE
			strKeyPath64 = "SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
			strKeyPath32 = "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
			' Connect to registry provider on target machine with current user
			 uninstalltool strkeypath64 , struninstall
			 uninstalltool strkey32 , struninstall
			
			oWsh.CurrentDirectory = strCurrentDir
			
			'strcmd = chr(34) & strCurrentDir &  "\RegistryCleanUpApp.exe" & chr(34) & " " & "/quiet" & " " & "/l*v" & " " & chr(34) & tmpFolder1  &        "\EmailValidationToolForAccentureInstall.log" & chr(34)
			strcmd ="runas.exe" & chr(34) & strCurrentDir &  "\RegistryCleanUpApp.exe/s /v\""/qn\""" & chr(34) & " " & "/quiet" & " " & "/l*v" & " " & chr(34) & tmpFolder1  &        "\EVTAInstall1.0.12.log" & chr(34)

			intret1 = oWsh.run(strcmd, ,true) 
			
			' deleting old files and folders
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "Deleting residual files and folders."
			
			Set folder = fso.GetFolder( tmpFolder1 & "\Email Validation Tool for Accenture")

			' delete all files in root folder
			for each f in folder.Files
			   On Error Resume Next
			   name = f.name
			   f.Delete True
			   If Err Then
				 WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "Error deleting:" & Name & " - " & Err.Description
			   Else
				 WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "Deleted:" & Name
			   End If
			   On Error Resume Next
			Next

			' delete all subfolders and files
			For Each f In folder.SubFolders
			   On Error Resume Next
			   name = f.name
			   f.Delete True
			   If Err Then
				 WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "Error deleting:" & Name & " - " & Err.Description
			   Else
				 WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "Deleted:" & Name
			   End If
			   On Error Resume Next
			Next

			'verifying tool installed
			UninstallTool strKeyPath64 , strCheck
			UninstallTool strKeyPath32 , strCheck
			If (strValueafterinstall <> toolVersion) Then
				WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Uninstallation finished**************" 
			end if
				WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Script Ended**************"
			WScript.quit(intret1)
		end If

'******************************************************************************************************************************************

'To write log file
Function WritetoLog(Filename, WhatToWrite)	

	If InStr(FILENAME,Chr(34)) > 0 Then	
		Filename = Left(Filename, Len(Filename) -1)
		Filename = Right(Filename, Len(Filename) -1)
	End If
	Set objFSO = CreateObject("Scripting.FileSystemObject")
	Set objFile = objFSO.OpenTextFile(Filename, 8, TRUE)	
	objFile.WriteLine WhatToWrite	
	objFile.Close
	
End Function

'To UninstallTool Anc Check if new tool is installed or not
Function UninstallTool (strKeyPath , uninstallOrCheck )

DIM KEYNAME
	'OEVT Agent Tool Local Variables'
	strToolDisplayName = "Email Validation Tool for Accenture"
	strDisplayName = "DisplayName"
	strDisplayVersion = "DisplayVersion"
	strInstallSource = "InstallSource"
	oReg.EnumKey hDefKey, strKeyPath, arrSubKeys
		For Each strSubkey In arrSubKeys	
		' Show the subkey create the key to open to read Display Version and Install location 
		KEYNAME =  strKeyPath & "\" & strSubkey
		oReg.GetStringValue HKEY_LOCAL_MACHINE, KEYNAME, strDisplayName , strValueDisplayName
		'if the key if of EVT Agent then get install source and uninstall the tool'
		IF(strValueDisplayName = strToolDisplayName) THEN 
		
			oReg.GetStringValue HKEY_LOCAL_MACHINE, KEYNAME, strDisplayVersion , strValueVersion
			oReg.GetStringValue HKEY_LOCAL_MACHINE, KEYNAME, strInstallSource , strInstallSourceLocationResult
			IF  ( uninstallOrCheck = strUninstall) THEN
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Tool is already installed.  GUID = " & strSubkey &"**************"
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Tool Display Name =" & strValueDisplayName & "**************"
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Tool Display Version  =" & strValueVersion & "**************"
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Tool Install Source =" & strInstallSourceLocationResult & "**************"
			strMSILocation = strInstallSourceLocationResult
			'To stop the service before uninstall
				DIM strComputer, serviceName
				strComputer = "." 
				Set objWMIService = GetObject("winmgmts:" _ 
				& "{impersonationLevel=impersonate}!\\" & strComputer & "\root\cimv2") 
			     WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Email Validation Tool for Accenture is already installed on machine. Uninstall started**************"			 
				 struninstall = "msiexec" & " " & "/x" & " " & chr(34) & strMSILocation & "\EmailValidationToolForAccentureSetup_MSI.msi "& chr(34) & " " &"/passive" & " " & "/l*v" & " " & chr(34) & tmpFolder1  & "\EmailValidationToolForAccentureUninstall.log" & chr(34)
			     intret = oWsh.run(struninstall, ,true) 
			     WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Tool uninstalled Successfully**************" & " with exit code: " & intret
				 WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "**************************************************************************************************************"
			ELSEIF (uninstallOrCheck = strCheck) THEN 
			strValueafterinstall = strValueVersion
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Only To Check if tool is intalled successfully of not**************"
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Tool is now installed.  GUID = " & strSubkey &"**************"
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Tool Display Name =" & strValueDisplayName & "**************"
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Tool Display Version  =" & strValueVersion & "**************"
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "     " & "***********Tool Install Source =" & strInstallSourceLocationResult & "**************"
			WritetoLog tmpFolder1 & "\Email Validation Tool for Accenture.log", Now() & "**************************************************************************************************************"
			END IF 
		END IF
		Next
END Function


