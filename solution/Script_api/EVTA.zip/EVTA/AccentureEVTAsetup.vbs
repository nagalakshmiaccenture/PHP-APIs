On error resume next 

strComputer = "."

Dim WshShell, tmpStr

Set WshShell = CreateObject("WScript.Shell")
strCurrentDir = Left(Wscript.ScriptFullName, (InstrRev(Wscript.ScriptFullName, "\") -1))


bkeyFinal = "msiexec /i" & " " & chr(34) & strCurrentDir & "\EmailValidationToolForAccentureSetup_MSI.msi" & chr(34) & " " & "/qn"


WshShell.Run BKeyFinal,0,True