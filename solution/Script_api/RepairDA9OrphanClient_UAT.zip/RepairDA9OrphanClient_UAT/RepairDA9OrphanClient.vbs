'********************************************************************************************************************
'Description : Script to Repair DA9 Orphan client, remove old registry policy and import DA9 registry policy file
'********************************************************************************************************************
'  All Right Reserved (C) Accenture
'  Author : Manoj Kumar
'  Date : 6 July 2020
'********************************************************************************************************************

Set sho = CreateObject("WScript.Shell") 
Set FSO = CreateObject("Scripting.FileSystemObject")
On error resume next 
strCurrentDir = Left(Wscript.ScriptFullName, (InstrRev(Wscript.ScriptFullName, "\") -1))
strcmd =chr(34) & strcurrentDir & "\RepairDA9OrphanClient.exe" & chr(34) & " -s" & " -f1"&chr(34) & strcurrentDir & "\RepairDA9OrphanClient.iss" & chr(34)
intret=sho.run(strcmd,0,vbtrue) 
WScript.Sleep 2000
WScript.Quit(intret)





